<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
				</div>
			</div>
			<div class="page-footer">
				<div class="page-footer-inner"> Copyright @Leica Biosystems Nussloch GmbH - 2018. Powered by 
					<a href="https://www.bluenettech.com/" target="_blank" class="makerCss">Bluenet</a>
				</div>
				<div class="scroll-to-top">
					<i class="material-icons">eject</i>
				</div>
			</div> 
		</div>
		<script src="<?php echo base_url('assets/plugins/jquery-blockui/jquery.blockui.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/jquery-slimscroll/jquery.slimscroll.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/bootstrap/js/bootstrap.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/counterup/jquery.waypoints.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/counterup/jquery.counterup.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/chart-js/Chart.bundle.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/chart-js/utils.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/js/pages/chart/chartjs/chartjs-data.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/js/app.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/js/layout.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/buttons/1.5.1/js/dataTables.buttons.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/ajax/libs/jszip/3.1.3/jszip.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/ajax/libs/pdfmake/0.1.32/pdfmake.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/ajax/libs/pdfmake/0.1.32/vfs_fonts.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/buttons/1.5.1/js/buttons.html5.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/js/pages/table/table_data.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/material/material.min.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/select2/js/select2.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/js/pages/select2/select2-init.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/plugins/jquery-validation/js/jquery.validate.js'); ?>"></script>
	    <script src="<?php echo base_url('assets/js/script.js'); ?>"></script>
		<script src="<?php echo base_url("assets/js/tinymce-settings.js"); ?>"></script>
		<script src="<?php echo base_url("assets/js/jquery.growl.js"); ?>"></script>

		<!-- <script src="<?php //echo base_url('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>"></script> -->

		<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'a2plcpnl0182'})
		</script>
		<script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script>
	</body>
</html>